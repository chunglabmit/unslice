UNSLICE (Unification of Neighboring Sliced-tissues via Linkage of Interconnected Cut fiber Endpoints)

UNSLICE is a Python package used specifically for interslab registration of cut tissue slabs for intact tissue reconstruction. It also can be used generally for large scale multi-modal or multi-round image registration, or for the segmentation and tracing of vasculature and neural fibers. 